window.start()
